class Todo < ActiveRecord::Base
end
