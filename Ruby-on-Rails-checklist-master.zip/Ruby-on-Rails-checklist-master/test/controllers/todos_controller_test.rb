require 'test_helper'

class TodosControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
